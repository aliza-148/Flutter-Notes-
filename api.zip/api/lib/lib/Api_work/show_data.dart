import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';

// Student model
class Student {
  final String id;
  final String studentId;
  final String name;
  final String course;
  final String image;

  Student({
    required this.id,
    required this.studentId,
    required this.name,
    required this.course,
    required this.image,
  });

  factory Student.fromJson(Map<String, dynamic> json) {
    return Student(
      id: json['id'].toString(),
      studentId: json['student_id'] ?? '',
      name: json['name'] ?? '',
      course: json['course'] ?? '',
      image: json['image'] ?? '',
    );
  }
}

// Main student list page
class StudentListPage extends StatefulWidget {
  @override
  _StudentListPageState createState() => _StudentListPageState();
}

class _StudentListPageState extends State<StudentListPage> {
  late Future<List<Student>> students;

  @override
  void initState() {
    super.initState();
    students = fetchStudents();
  }

  Future<List<Student>> fetchStudents() async {
    final url = Uri.parse('https://api.oratiodev.com/api/student');
    final response = await http.get(url);

    if (response.statusCode == 200) {
      final jsonBody = json.decode(response.body);
      final List data = jsonBody['students'];
      return data.map((e) => Student.fromJson(e)).toList();
    } else {
      throw Exception('Failed to load students');
    }
  }

  Future<void> deleteStudent(String id) async {
    final url = Uri.parse('https://api.oratiodev.com/api/student/$id/delete');
    final response = await http.delete(url);

    if (response.statusCode == 200) {
      final responseBody = json.decode(response.body);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(responseBody['Error'] ?? 'Student deleted')),
      );

      setState(() {
        students = fetchStudents(); // Refresh list
      });
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to delete student')),
      );
    }
  }

  void refreshStudents() {
    setState(() {
      students = fetchStudents();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Students List'),
        backgroundColor: Colors.teal,
        actions: [
          IconButton(
            icon: Icon(Icons.refresh),
            onPressed: refreshStudents,
            tooltip: 'Refresh',
          ),
        ],
      ),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            DrawerHeader(
              decoration: BoxDecoration(color: Colors.teal),
              child: Text(
                'Menu',
                style: TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.bold),
              ),
            ),
            ListTile(
              leading: Icon(Icons.list, color: Colors.teal),
              title: Text('Students List'),
              onTap: () {
                Navigator.pop(context);
              },
            ),
            ListTile(
              leading: Icon(Icons.add, color: Colors.teal),
              title: Text('Add Student'),
              onTap: () {
                Navigator.pop(context);
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => StudentForm()),
                ).then((_) => refreshStudents());
              },
            ),
          ],
        ),
      ),
      body: FutureBuilder<List<Student>>(
        future: students,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator(color: Colors.teal));
          } else if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}', style: TextStyle(color: Colors.red)));
          } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return Center(child: Text('No students found.', style: TextStyle(fontSize: 18)));
          }

          final studentList = snapshot.data!;
          return ListView.builder(
            padding: EdgeInsets.symmetric(vertical: 8),
            itemCount: studentList.length,
            itemBuilder: (context, index) {
              final student = studentList[index];

              final imageUrl = student.image.isNotEmpty
                  ? student.image.startsWith('http')
                  ? student.image
                  : 'https://api.oratiodev.com/images/${student.image.split('/').last}'
                  : '';

              return Card(
                elevation: 4,
                margin: EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                child: ListTile(
                  contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  leading: student.image.isNotEmpty
                      ? ClipRRect(
                    borderRadius: BorderRadius.circular(8),
                    child: Image.network(
                      imageUrl,
                      width: 50,
                      height: 50,
                      fit: BoxFit.cover,
                      errorBuilder: (context, error, stackTrace) {
                        return Icon(Icons.image_not_supported, color: Colors.grey);
                      },
                    ),
                  )
                      : CircleAvatar(
                    backgroundColor: Colors.teal.shade100,
                    child: Icon(Icons.person, color: Colors.teal),
                  ),
                  title: Text(
                    student.name,
                    style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                  ),
                  subtitle: Text('${student.course} | ID: ${student.studentId}'),
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      IconButton(
                        icon: Icon(Icons.edit, color: Colors.teal),
                        tooltip: 'Edit',
                        onPressed: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => StudentForm(student: student),
                            ),
                          ).then((_) => refreshStudents());
                        },
                      ),
                      IconButton(
                        icon: Icon(Icons.delete, color: Colors.redAccent),
                        tooltip: 'Delete',
                        onPressed: () {
                          showDialog(
                            context: context,
                            builder: (context) => AlertDialog(
                              title: Text('Confirm Delete'),
                              content: Text('Are you sure you want to delete this student?'),
                              actions: [
                                TextButton(
                                  child: Text('Cancel', style: TextStyle(color: Colors.teal)),
                                  onPressed: () => Navigator.of(context).pop(),
                                ),
                                TextButton(
                                  child: Text('Delete', style: TextStyle(color: Colors.redAccent)),
                                  onPressed: () {
                                    Navigator.of(context).pop();
                                    deleteStudent(student.id);
                                  },
                                ),
                              ],
                            ),
                          );
                        },
                      ),
                    ],
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}

// Student form page to add/update
class StudentForm extends StatefulWidget {
  final Student? student;

  StudentForm({Key? key, this.student}) : super(key: key);

  @override
  _StudentFormState createState() => _StudentFormState();
}

class _StudentFormState extends State<StudentForm> {
  final _formKey = GlobalKey<FormState>();
  late TextEditingController _studentIdController;
  late TextEditingController _nameController;
  late TextEditingController _courseController;

  File? _imageFile;
  final picker = ImagePicker();

  bool get isUpdate => widget.student != null;

  @override
  void initState() {
    super.initState();
    _studentIdController = TextEditingController(text: widget.student?.studentId ?? '');
    _nameController = TextEditingController(text: widget.student?.name ?? '');
    _courseController = TextEditingController(text: widget.student?.course ?? '');
  }

  Future<void> _pickImage() async {
    final pickedFile = await picker.pickImage(source: ImageSource.gallery);

    if (pickedFile != null) {
      setState(() {
        _imageFile = File(pickedFile.path);
      });
    }
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;

    final studentId = _studentIdController.text.trim();
    final name = _nameController.text.trim();
    final course = _courseController.text.trim();

    var uri = isUpdate
        ? Uri.parse('https://api.oratiodev.com/api/student/${widget.student!.id}/update')
        : Uri.parse('https://api.oratiodev.com/api/student');

    var request = http.MultipartRequest('POST', uri);

    request.fields['student_id'] = studentId;
    request.fields['name'] = name;
    request.fields['course'] = course;

    if (isUpdate) {
      request.fields['_method'] = 'PUT'; // Laravel fix for update
    }

    if (_imageFile != null) {
      request.files.add(await http.MultipartFile.fromPath('image', _imageFile!.path));
    } else if (!isUpdate) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Please select an image')),
      );
      return;
    }

    try {
      var streamedResponse = await request.send();
      var response = await http.Response.fromStream(streamedResponse);

      if (response.statusCode == 200) {
        final responseBody = json.decode(response.body);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(responseBody['message'] ?? 'Success'), backgroundColor: Colors.teal),
        );
        Navigator.of(context).pop();
      } else {
        print('Server Error: ${response.body}');
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed to submit data'), backgroundColor: Colors.redAccent),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: $e'), backgroundColor: Colors.redAccent),
      );
    }
  }

  @override
  void dispose() {
    _studentIdController.dispose();
    _nameController.dispose();
    _courseController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final imageUrl = widget.student?.image ?? '';

    return Scaffold(
      appBar: AppBar(
        title: Text(isUpdate ? 'Update Student' : 'Add Student'),
        backgroundColor: Colors.teal,
      ),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: ListView(
            children: [
              if (isUpdate && imageUrl.isNotEmpty && _imageFile == null)
                ClipRRect(
                  borderRadius: BorderRadius.circular(12),
                  child: Image.network(
                    imageUrl.startsWith('http')
                        ? imageUrl
                        : 'https://api.oratiodev.com/images/${imageUrl.split('/').last}',
                    height: 150,
                    fit: BoxFit.cover,
                  ),
                ),
              if (_imageFile != null)
                ClipRRect(
                  borderRadius: BorderRadius.circular(12),
                  child: Image.file(
                    _imageFile!,
                    height: 150,
                    fit: BoxFit.cover,
                  ),
                ),
              SizedBox(height: 12),
              TextButton.icon(
                onPressed: _pickImage,
                icon: Icon(Icons.image, color: Colors.teal),
                label: Text('Select Image', style: TextStyle(color: Colors.teal, fontWeight: FontWeight.bold)),
                style: TextButton.styleFrom(
                  backgroundColor: Colors.teal.shade50,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                  padding: EdgeInsets.symmetric(vertical: 12),
                ),
              ),
              SizedBox(height: 16),
              TextFormField(
                controller: _studentIdController,
                decoration: InputDecoration(
                  labelText: 'Student ID',
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
                  focusedBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.teal, width: 2)),
                ),
                validator: (val) => val == null || val.isEmpty ? 'Enter student ID' : null,
              ),
              SizedBox(height: 12),
              TextFormField(
                controller: _nameController,
                decoration: InputDecoration(
                  labelText: 'Name',
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
                  focusedBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.teal, width: 2)),
                ),
                validator: (val) => val == null || val.isEmpty ? 'Enter name' : null,
              ),
              SizedBox(height: 12),
              TextFormField(
                controller: _courseController,
                decoration: InputDecoration(
                  labelText: 'Course',
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
                  focusedBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.teal, width: 2)),
                ),
                validator: (val) => val == null || val.isEmpty ? 'Enter course' : null,
              ),
              SizedBox(height: 24),
              ElevatedButton(
                onPressed: _submit,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.teal,
                  padding: EdgeInsets.symmetric(vertical: 14),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                ),
                child: Text(
                  isUpdate ? 'Update' : 'Add',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
