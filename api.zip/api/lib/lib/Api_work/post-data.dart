import 'dart:io';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:path/path.dart';

void main() => runApp(MaterialApp(home: StudentForm()));

class StudentForm extends StatefulWidget {
  @override
  _StudentFormState createState() => _StudentFormState();
}

class _StudentFormState extends State<StudentForm> {
  final _formKey = GlobalKey<FormState>();
  final _idController = TextEditingController();
  final _nameController = TextEditingController();
  final _courseController = TextEditingController();
  File? _image;

  Future<void> _pickImage() async {
    final picked = await ImagePicker().pickImage(source: ImageSource.gallery);
    if (picked != null) {
      setState(() => _image = File(picked.path));
    }
  }

  Future<void> _submitData(BuildContext context) async {
    if (!_formKey.currentState!.validate()) return;

    final uri = Uri.parse('https://api.oratiodev.com/api/student');
    final request = http.MultipartRequest('POST', uri)
      ..fields['student_id'] = _idController.text
      ..fields['name'] = _nameController.text
      ..fields['course'] = _courseController.text;

    if (_image != null) {
      final imageFile = await http.MultipartFile.fromPath(
        'image',
        _image!.path,
        filename: basename(_image!.path),
      );
      request.files.add(imageFile);
    }

    final response = await request.send();
    final responseBody = await response.stream.bytesToString();

    if (response.statusCode == 200) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Success: $responseBody')),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: $responseBody')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Add Student')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: SingleChildScrollView(
            child: Column(
              children: [
                TextFormField(
                  controller: _idController,
                  decoration: InputDecoration(labelText: 'Student ID'),
                  validator: (value) =>
                  value!.isEmpty ? 'Enter student ID' : null,
                ),
                TextFormField(
                  controller: _nameController,
                  decoration: InputDecoration(labelText: 'Name'),
                  validator: (value) =>
                  value!.isEmpty ? 'Enter name' : null,
                ),
                TextFormField(
                  controller: _courseController,
                  decoration: InputDecoration(labelText: 'Course'),
                  validator: (value) =>
                  value!.isEmpty ? 'Enter course' : null,
                ),
                SizedBox(height: 10),
                _image != null
                    ? Image.file(_image!, height: 100)
                    : Text('No image selected'),
                ElevatedButton(
                  onPressed: _pickImage,
                  child: Text('Pick Image'),
                ),
                SizedBox(height: 20),
                ElevatedButton(
                  onPressed: () => _submitData(context),
                  child: Text('Submit'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
